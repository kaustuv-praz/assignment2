import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ActionEvent;

import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

 


public class CBabyBallBounce extends JFrame implements ActionListener{
	
	private JMenuBar jmenubar;  //menu bar


	private JPanel first,inside,side, panChar,side1,group1,group2,group3,dirPan,  numberOfPlayers; //panels for 
	private ImageIcon p1,p2,p3; //image icons 
	private JLabel time,  dotDot, dotDot1, scoreLabel, showScore, labelSpeed, optionLabel, jLabel2, jLabel3, label5;
	private JTextField second, min, hour, player1,  player2, jOption1,jOption2, way,jLabel12;
	
	private JButton bb[],blank1,blank2,blank3,blank4,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton9,jButton10,jButton11,jButton12, buttonCompass,  PlayerTwoButton,  PlayerFourButton, 
	PlayerMultiButton,buttonExiting, buttonAct;
	Font font1;
	  int curPosition = 100;
	    int babyPosition = 100;
	private int positionW;
	private int positionM;
	int positionNow = 101;
 	int positionTemp;
	private int a=1 ,c=1,e =1;
	private Timer t1,t2,t3;
	int wall = 8;
	int wall1 = 7;
	int b1 = 98;
	int b2 = 108;
	
	
	int moveVal = 0;
	static int bal = 100;
	int preBal;
	int right = 1;
	int left = -1;
	int up = -16;
	int down = 16;
	 private int ticks = 0;
	    private Timer timer;
	int count = 0;
	int x=6,y=8,z=2;
 
	//Images as global.
	
	 ImageIcon baby1 = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/baby1.png");
	    ImageIcon barrier = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/bricks2.jpg");
	    ImageIcon baby2 = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/baby2.png");
	    ImageIcon white = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/white32x32.jpg");
	    ImageIcon ball = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/ball.png");
 
    
    
	public static void main(String[] args)  //Main method.
	{
		CBabyBallBounce frame= new CBabyBallBounce ();  //Object frameMain created inside CBabyBallBounce constructor.
		frame.createGUI();     //GUI created for the object
		frame.setResizable(false);
		frame.setSize(825,585);  //objects's size declared.
		frame.setVisible(true);   
		frame.setTitle("                                                                   CBabyBallBounce- Baby Ball Bounce Application");
		frame.setLocationRelativeTo(null);
		
		
		
	}
	
	public void createGUI(){  //GUI of the Object frameMain
		
		menubar();
		sidePanel();
		downPanel();
		
	}
	
	public void menubar(){    //Menu bar Frame.
		
		setDefaultCloseOperation(EXIT_ON_CLOSE); //window with close button.
		Container window = getContentPane();
		window.setLayout(new FlowLayout());
		
		 JMenuBar jmenubar = new JMenuBar();
		 jmenubar.setPreferredSize(new Dimension(825,21));
		    jmenubar.setBackground(Color.white);
			 window.add(jmenubar);
		    JMenu scenario=new JMenu("Scenario");
		    jmenubar.add(scenario);
		    JMenuItem exiting=new JMenuItem("Exiting");
		    scenario.add(exiting);
		   
		    JMenuItem open=new JMenuItem("Open");
		    scenario.add(open);
		   
		    JMenu edit=new JMenu("Edit");
		    jmenubar.add(edit);
		   
		   JMenu control=new JMenu("Controls");
		   jmenubar.add(control);
		   
		   JMenu Help=new JMenu("Help");
		   jmenubar.add(Help);
		   JMenuItem about= new JMenuItem("About");
		   Help.add(about);
		   

	}
	
	
	
        public void sidePanel(){    //the characters are placed in this panel
        	setDefaultCloseOperation(EXIT_ON_CLOSE);
    		Container window = getContentPane();
    		window.setLayout(new FlowLayout());
    		
        first = new JPanel(); //panel named first is created
        first.setPreferredSize(new Dimension(641,478));
        first.setBorder(new LineBorder(Color.GRAY,1));
         window.add(first); //panOne add in win. 
        
      
        inside = new JPanel(); //created a panel called pachadiPan 
        inside.setBorder(new LineBorder(Color.BLACK,1));
        inside.setPreferredSize(new Dimension(551, 460));
        inside.setLayout(new GridLayout(13,16));  //Grid layout set to 13*16.
        first.add(inside);
        
        
    	bb = new JButton[208];
		
		for (int i = 0; i < 208; i++) {
	
		            if(i==curPosition)
		        		bb[i]=new JButton(white);
		        	else if(i==babyPosition){
		        		bb[i]=new JButton(ball);
		        		 jOption2.setText(Integer.toString(i));
		        	}
		        	else bb[i]=new JButton(white);
		        	
		        	if(i==wall){
		                bb[i].setIcon(barrier);
		        	    wall+=16;
		      
		        	}
		        	if(i==wall1){
		        	    bb[i].setIcon(barrier);
		        		wall1+=16;
		        	}
		        	if(i==b1){
		        		bb[i].setIcon(baby1);	
		        	}
		        if(i==b2){
		        	bb[i].setIcon(baby2);
		        }
		        if(i==bal){
		        	bb[i].setIcon(ball);
		           }
		        
			bb[i].setBorder(null);
		        bb[i].setBackground(Color.WHITE);
		    inside.add(bb[i]);}
				
		  //new variable assigned as b JButton to locate baby ball and barrier in the pachadiPan Jpanel.
	
			
		
		
		

         side= new JPanel(); //panDui JPanel is created left to pachadiPan JPanel.
         side.setBorder(new LineBorder(Color.GRAY));
         side.setPreferredSize(new Dimension(160, 475));
         side.setLayout(new FlowLayout());        
         window.add(side);
         
        
         
         
         
        
         time = new JLabel("      DIGITAL TIMER      ");  //Timer
         time.setPreferredSize(new Dimension(120,20));   //size of the textField
         side.add(time);
         
           
         hour = new JTextField();    //JTextField called oneField is created.
         
         hour.setBackground(Color.BLACK);  //background color is black.
         hour.setForeground(Color.WHITE);   //text color is white while background is black
         hour.setPreferredSize(new Dimension(35,20));   //size of the textField
         hour.setAlignmentX(FlowLayout.RIGHT);       //layout is on right side.
         hour.setText("00");
         side.add(hour);
         
         dotDot = new JLabel(":");   //JLabel called labelTwo is created
         side.add(dotDot);
         
         min = new JTextField();      //JTextField called twoField is created.
         min.setBackground(Color.BLACK);
         min.setForeground(Color.WHITE);
         min.setPreferredSize(new Dimension(35,20));
         min.setAlignmentX(FlowLayout.CENTER); //layout is on the center 
         min.setText("00");
         side.add(min);
         
         dotDot1 = new JLabel(":");
         side.add(dotDot1);
         
         second = new JTextField();      //JTextField called threeField is created.
         second.setPreferredSize(new Dimension(36,20));
         second.setBackground(Color.BLACK);
         second.setForeground(Color.WHITE);
         second.setAlignmentX(FlowLayout.RIGHT);
         second.setText("00");
         side.add( second);
         
        
         //score board
     
    
         scoreLabel = new JLabel("              SCORE   ");  //JLabel called labelScore to show score. 
         scoreLabel.setPreferredSize(new Dimension(120,20));   //size of the textField
         side.add(scoreLabel);
         
         player1 = new JTextField();    //JTextField called fourField is created.
         player1.setBackground(Color.BLACK);
         player1.setForeground(Color.WHITE);
         player1.setPreferredSize(new Dimension(36,20));
         player1.setAlignmentX(FlowLayout.LEFT);   //layout assigned to Left.
         player1.setText("00");
         side.add( player1);
         
         showScore= new JLabel("\t < L : R > ");    //score counter
         side.add(showScore);
         
         
         player2= new JTextField();   //JTextField called player2 is created.
         player2.setBackground(Color.BLACK);
         player2.setForeground(Color.WHITE);
         player2.setPreferredSize(new Dimension(36,20));
         player2.setAlignmentX(FlowLayout.RIGHT);  //layout is set to Right.
         player2.setText("00");
         side.add( player2);
         
         
         
         //option panel
         group1 = new JPanel();  //JPanel called optionPan is created 
         group1.setPreferredSize(new Dimension(150,29));
         side.add(group1);
         
         optionLabel = new JLabel("Option:");  //JLabel called optionLabel is created inorder to show the players option
         optionLabel.setPreferredSize(new Dimension(85,29));
         group1.add(optionLabel);
       
         //JTextField inside optionPan.
         jOption1 = new JTextField("2 player");
         jOption1.setPreferredSize(new Dimension(55,29));
         group1.add(jOption1);
         
         group2 = new JPanel(); //JPanel called squarePan is created.
         group2.setPreferredSize(new Dimension(145,29));
         side.add(group2);
         
         jLabel2 = new JLabel("Square:");
         jLabel2.setPreferredSize(new Dimension(80,29));
         group2.add(jLabel2);
         
         jOption2 = new JTextField("101");
         jOption2.setPreferredSize(new Dimension(55,29));
         group2.add(jOption2);
         
         group3 = new JPanel();  //JPanel called dirPan is created, it is an frame that holds direction button and other controls.
         group3.setPreferredSize(new Dimension(145,29));
         side.add(group3);
         
         
         //Direction panel 
         jLabel3 = new JLabel("Direction:");  //JLabel called labelDir is created
         jLabel3.setPreferredSize(new Dimension(80,29));
         group3.add(jLabel3);
         
         way= new JTextField("SE");  //JTextField called directoryField is created.
         way.setPreferredSize(new Dimension(50,25));
         group3.add(way);
         
         side1= new JPanel();   //JPanel called panPanch is created
         side1.setPreferredSize(new Dimension(150,75));
         side1.setLayout(new GridLayout(3,3,2,1));  //grid layout is set.
         side.add(side1);
         side1.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);   //layout is set to right.
         
       
      
       //Ball controller part.
       blank1 = new JButton(); //JButton called buttonOne is created. 
       blank1.setBorder(BorderFactory.createBevelBorder(1));   //this button is empty and has border type BevelBorder.
       side1.add(blank1);
       
       
       
       jButton1= new JButton("^");  //JButton called buttonTwo is created, indicates up.
       jButton1.setBackground(Color.WHITE);   //background color is set to white.
       side1.add(jButton1);
       
       
      // jButton2.setActionCommand("^");
       jButton1.addActionListener(this);
    	     //buttonTwo is added to action listener for an event. 
       
       blank2 = new JButton();  //JButton called buttonThree is created. 
       blank2.setBorder(BorderFactory.createBevelBorder(1));   //this button is empty and has border type BevelBorder.
       side1.add(blank2);
       
       
       jButton4 = new JButton("<");   //JButton called buttonFour is created, indicates left.
       jButton4.setBackground(Color.WHITE); 
       jButton4.setActionCommand("<");
       side1.add( jButton4);
       jButton4.addActionListener(this); //buttonTwo is added to action listener for an event.
    
       
  
       
       ImageIcon ballImage= new ImageIcon("C:/Users/user/Desktop/Assignment2/src/ball.png");
       
       jButton5 = new JButton(ballImage);   //JButton called buttonFive is created. 
      
       side1.add( jButton5);
       
       jButton6 = new JButton(">");   //JButton called button, indicates right.
       jButton6.setBackground(Color.WHITE);
       jButton6.addActionListener(this); //buttonTwo is added to action listener for an event.
       
       side1.add( jButton6);
         
       blank3 = new JButton();  //JButton called buttonSeven is created.
       blank3.setBorder(BorderFactory.createBevelBorder(1));
       side1.add(blank3);
       
       
       jButton7 = new JButton("v");  //JButton called buttonaEight is created, indicates down.
       jButton7.addActionListener(this); //buttonTwo is added to action listener for an event.
       jButton7.setBackground(Color.WHITE);
       side1.add( jButton7);
       
       blank4 = new JButton();  //JButton called buttonNine is created.
       blank4.setBorder(BorderFactory.createBevelBorder(1));
       side1.add(blank4);    
		    
       
       
       
      
         ImageIcon com = new ImageIcon("C:/Users/user/Desktop/Assignment2/src/east.jpg");  // by default compass is set to east.
         label5= new JLabel(com);   //JLabel called labelCompass is created.
         label5.setPreferredSize(new Dimension(150,90));        
        side.add(label5);
         
         //player numbers
         numberOfPlayers = new JPanel();  //JPanel called panChoose is created.
         numberOfPlayers.setLayout(new GridLayout(2,2,2,10));   //grid layout is set.
         numberOfPlayers.setPreferredSize(new Dimension(157,80));
         side.add( numberOfPlayers);
         numberOfPlayers.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);        //position of panChoose is set to right.
         PlayerTwoButton = new JButton("2Player");  //2player button is created 
         PlayerTwoButton.addActionListener(this);
         PlayerTwoButton.setBackground(Color.WHITE);
         numberOfPlayers.add(PlayerTwoButton);        
         
         PlayerFourButton = new JButton("4 Player");  //4 player button is created
         PlayerFourButton.addActionListener(this);
         PlayerFourButton.setBackground(Color.WHITE);
         numberOfPlayers.add( PlayerFourButton);     
         
         
         
         PlayerMultiButton = new JButton("Multi");   //button to choose multi players are created
         PlayerMultiButton.setBackground(Color.WHITE);
         PlayerMultiButton.addActionListener(this);
         numberOfPlayers.add(PlayerMultiButton);  
         PlayerMultiButton.addActionListener(this);
         
         
         
         buttonExiting = new JButton("Exit");    //to exit the game by clicking this button
         buttonExiting.setBackground(Color.WHITE);
         numberOfPlayers.add(buttonExiting);
         buttonExiting.addActionListener(new ActionListener()
         {
        	 @Override
     	public void actionPerformed(ActionEvent arg0){
     		System.exit(0);
     	}
     });
        }
          //controls for the game 
         
         public void downPanel(){    
        	 
        		setDefaultCloseOperation(EXIT_ON_CLOSE);
        		Container window = getContentPane();
        		window.setLayout(new FlowLayout());
        		
        
          
         
        JPanel down = new JPanel();
         // panel22.setLayout(new  GridLayout() );
         down.setPreferredSize(new Dimension(825, 50));
         down.setLayout(new FlowLayout());
         window.add(down);
         
          Icon act= new ImageIcon(getClass().getResource("step.png"));
          jButton9=new JButton("Act",act);
          jButton9.setBackground(Color.white);
          jButton9.addActionListener(this); 
          down.add(jButton9);
        
          
          
          Icon run= new ImageIcon(getClass().getResource("run.png"));
       
         jButton10=new JButton("Run",run);
         jButton10.setBackground(Color.white);
         jButton10.addActionListener(this);
         
         
         down.add(jButton10);


         
         Icon reset= new ImageIcon(getClass().getResource("reset.png"));
         jButton11=new JButton("Reset",reset);
         jButton11.setBackground(Color.white);
         down.add(jButton11);
         jButton11.addActionListener(this);
  
        
      
        
      
 		
 		 JLabel speed1 = new JLabel("                             Speed");
 		   speed1.setBounds(535, 16, 50, 15);
 		   down.add(speed1);  
 		   JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 4, 0);
 		   slider.setMajorTickSpacing(1);
 	 	   slider.setPaintTicks(true);
 	       down.add(slider);
 	 		
 	 
 		   
 		  timing();
         
	}
         
		
        	
        			
		

		public void actionPerformed(ActionEvent event) {
        	    
         if(event.getSource() == jButton1) {
 			kickBall("up");
 			 
 		}
 		else if(event.getSource() ==  jButton7){
 			kickBall("down");
 			 
 		}
 		else if(event.getSource() ==  jButton6){
 			kickBall("right");
 			
 		}
 		else if(event.getSource() ==  jButton4) {
 			kickBall("left");
 			
 		}
         if (event.getSource() == PlayerTwoButton){
        	 jOption1.setText("2 players");
    		 bb[98].setIcon(baby1);
    		 bb[108].setIcon(baby2);
    		 bb[66].setIcon(null);
    		 bb[130].setIcon(null);
    		 bb[76].setIcon(null);
    		 bb[140].setIcon(null);
    		 
    	 }
         if(event.getSource() ==  PlayerFourButton){
        	 jOption1.setText("4 players");
    		 bb[66].setIcon(null);
    		 bb[130].setIcon(baby1);
    		 bb[76].setIcon(null);
    		 bb[140].setIcon(baby2);
    
    	 }
 	 
         if(event.getSource() == PlayerMultiButton){
        	 jOption1.setText("Multi");
    		 bb[66].setIcon(baby1);
    		 bb[130].setIcon(baby1);
    		 bb[76].setIcon(baby2);
    		 bb[140].setIcon(baby2);
    		 
    		
    	 }
 		
 	
 	
 		 if(event.getSource() == jButton11){
 			dispose();
 			  bal=99;
 			 CBabyBallBounce frame= new CBabyBallBounce ();  
 			frame.setResizable(false);
 			frame.createGUI();     
 			frame.setSize(825,585);  
 			frame.setTitle("                                                                   CBabyBallBounce- Baby Ball Bounce Application");
 			frame.setVisible(true);   
 			frame.setLocationRelativeTo(null);
 			
 	      
 	       
 		}
 		else if(event.getSource() ==jButton10 ) {
 			timing();
 		}
 		
 		 min.setText(Integer.toString(ticks / 60));
          second.setText(Integer.toString(ticks % 60));
          hour.setText(Integer.toString(ticks /360/360));
          ticks = ticks + 1;

        		
        		 
				}

			
				

     	private void timing() {
         	  timer = new Timer(1000, this);
               timer.start();
               
     		
     	}
     public void kickBall(String a) {
     
     		if(a == "right") {
     		
     	
    				
    				
    					
     			
    				
     			 way.setText("SE");
     		      label5.setIcon(new ImageIcon("C:/Users/user/Desktop/Assignment2/src/east.jpg"));
     		}
     		else if(a == "left") {
     		
     		
    				
     			 way.setText("SW");
     			 label5.setIcon(new ImageIcon("C:/Users/user/Desktop/Assignment2/src/west.jpg"));
     		}
     		else if(a == "up") {

    		
     			way.setText("SN");
     			label5.setIcon(new ImageIcon("C:/Users/user/Desktop/Assignment2/src/north.jpg"));
     		
     		}
     		else if(a == "down") {
     		
     			way.setText("SS");
     			label5.setIcon(new ImageIcon("C:/Users/user/Desktop/Assignment2/src/south.jpg"));
     			
     		}
  
     	
				
			}
				
			
		

	
     		 
     		}
				
			
			
			
		
			
		
	
 


     



	

